package com.workingdomaintest;

public class WorkingDomainTest {

}
