package com.WorkingDomain;

public class Validator  {

	public void validateindto(WorkingDomainIndto indtovalidate) {
		//use proper exception handling logic in this method to validate the field
		//catch the exception error message in the catch block
		
	}
}
