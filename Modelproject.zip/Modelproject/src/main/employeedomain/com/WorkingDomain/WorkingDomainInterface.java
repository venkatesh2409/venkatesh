package com.WorkingDomain;

public interface WorkingDomainInterface {

	public WorkingDomainOutdto currentDomainmethod(WorkingDomainIndto indto);
	
}
