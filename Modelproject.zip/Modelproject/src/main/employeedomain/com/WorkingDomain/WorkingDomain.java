package com.WorkingDomain;

public class WorkingDomain implements WorkingDomainInterface {
	
	public WorkingDomainOutdto currentDomainmethod(WorkingDomainIndto indto) {
		
		//validate  the  indto fields using proper validation and throw proper error message using exception handling.
		
		//Validator validate= new Validator();
		
		//Call the validator method with proper arguments;
		
		//call the method of the different domain(DOMAIN TO BE MOCKED)
		
		//  input  or the  inDTo fields  of the  mocking domain  is  set from  the INDTO field of the current domain
		
		// OUtDTo fields of   Mockdomain is set   to the workingDomain OUTDTO
		
		
		//return WorkingDomainoutdto;
	}

}
