package com.mockingDomain;

public interface MockingDomainInterface {
	public MockingDomainOtdto mockingmethod();
}
