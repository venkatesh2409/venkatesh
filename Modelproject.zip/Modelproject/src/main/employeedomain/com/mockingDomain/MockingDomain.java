package com.mockingDomain;

public class MockingDomain {

	public MockingDomainOtdto mockingmethod() {
		
		// use of the this method is to add   the Rs 5000 to the current object salary part and  set that to the bonus field
		
		//return mockingDomainOtdto;
		
	}
}
